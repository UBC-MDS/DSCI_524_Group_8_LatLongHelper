# Changelog

<!--next-version-placeholder-->

## v0.1.0 (05/01/2026)

- First release of `latlonghelper`!